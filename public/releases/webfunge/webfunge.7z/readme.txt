Webfunge
by Bloutiouf

This is the version as it was presented at the Evoke 2014.

For the latest version, see https://github.com/Bloutiouf/Webfunge
